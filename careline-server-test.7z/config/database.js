module.exports = {
  // 'url': 'mongodb://careline:alex2005@ds040017.mlab.com:40017/careline'
  //'url': 'mongodb://careline:alex2005@127.0.0.1/careline?authMechanism=SCRAM-SHA-1'
  'url': 'mongodb://liangw7:alex2005@127.0.0.1:27017/careline?maxPoolSize=2&socketTimeoutMS=600000'
  //'url': 'mongodb://liangw7:Outlook!2018@127.0.0.1/careline'
 // 'url': 'mongodb://careline:alex2005@127.0.0.1/careline'
  //'mongodb://用户名:登陆密码@127.0.0.1/databaseFoo';
//  'url': 'mongodb://liangw7:alex2005@47.101.41.210:27017/careline'
}